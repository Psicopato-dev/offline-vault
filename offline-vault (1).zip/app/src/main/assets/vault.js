/* vault.js — шифрование и хранение данных. Не зависит от DOM.
 *
 * Хранилище = один зашифрованный блок в localStorage:
 *   ключ  = PBKDF2-SHA256(мастер-пароль, соль, 600 000 итераций)
 *   шифр  = AES-256-GCM (с проверкой целостности)
 * Ключ существует только в памяти и пропадает при блокировке.
 */
(function (root) {
  'use strict';

  var STORAGE_KEY = 'vault.v1';
  var ITER = 600000;
  var enc = new TextEncoder();
  var dec = new TextDecoder();

  var key = null;      // CryptoKey (неизвлекаемый)
  var salt = null;     // Uint8Array
  var iter = ITER;
  var entries = [];

  // ---------- вспомогательное ----------
  function toB64(buf) {
    var bytes = new Uint8Array(buf), s = '';
    for (var i = 0; i < bytes.length; i += 0x8000) {
      s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    }
    return btoa(s);
  }

  function fromB64(str) {
    var bin = atob(str), out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  function randomBytes(n) {
    return crypto.getRandomValues(new Uint8Array(n));
  }

  function uid() {
    return Array.prototype.map.call(randomBytes(12), function (b) {
      return ('0' + b.toString(16)).slice(-2);
    }).join('');
  }

  async function deriveKey(password, saltBytes, iterations) {
    var base = await crypto.subtle.importKey(
      'raw', enc.encode(password.normalize('NFKC')), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey(
      { name: 'PBKDF2', hash: 'SHA-256', salt: saltBytes, iterations: iterations },
      base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }

  function parseBlob(text) {
    var b;
    try { b = JSON.parse(text); } catch (e) { throw new Error('bad_format'); }
    if (!b || b.v !== 1 || typeof b.salt !== 'string' || typeof b.iv !== 'string' ||
        typeof b.data !== 'string' || !(b.iter >= 100000 && b.iter <= 5000000)) {
      throw new Error('bad_format');
    }
    return b;
  }

  async function decryptBlob(blob, k) {
    try {
      var plain = await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: fromB64(blob.iv) }, k, fromB64(blob.data));
      var obj = JSON.parse(dec.decode(plain));
      if (!obj || !Array.isArray(obj.entries)) throw new Error('x');
      return obj.entries;
    } catch (e) {
      throw new Error('bad_password');
    }
  }

  async function save() {
    var iv = randomBytes(12);
    var plain = enc.encode(JSON.stringify({ entries: entries }));
    var ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv }, key, plain);
    var blob = {
      v: 1, kdf: 'PBKDF2-SHA256', iter: iter,
      salt: toB64(salt), iv: toB64(iv), data: toB64(ct)
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(blob));
  }

  function requireUnlocked() {
    if (!key) throw new Error('locked');
  }

  // ---------- публичный API ----------
  var Vault = {
    exists: function () { return !!localStorage.getItem(STORAGE_KEY); },
    isUnlocked: function () { return !!key; },

    create: async function (password) {
      salt = randomBytes(16);
      iter = ITER;
      key = await deriveKey(password, salt, iter);
      entries = [];
      await save();
    },

    unlock: async function (password) {
      var text = localStorage.getItem(STORAGE_KEY);
      if (!text) throw new Error('no_vault');
      var blob = parseBlob(text);
      var k = await deriveKey(password, fromB64(blob.salt), blob.iter);
      var list = await decryptBlob(blob, k);   // бросит bad_password
      key = k; salt = fromB64(blob.salt); iter = blob.iter; entries = list;
    },

    verify: async function (password) {
      try {
        var blob = parseBlob(localStorage.getItem(STORAGE_KEY));
        var k = await deriveKey(password, fromB64(blob.salt), blob.iter);
        await decryptBlob(blob, k);
        return true;
      } catch (e) { return false; }
    },

    lock: function () { key = null; salt = null; entries = []; },

    wipe: function () { Vault.lock(); localStorage.removeItem(STORAGE_KEY); },

    list: function () { requireUnlocked(); return entries.slice(); },
    get: function (id) {
      requireUnlocked();
      for (var i = 0; i < entries.length; i++) if (entries[i].id === id) return entries[i];
      return null;
    },

    add: async function (data) {
      requireUnlocked();
      var now = Date.now();
      var e = {
        id: uid(), service: data.service, login: data.login || '',
        password: data.password, note: data.note || '', created: now, updated: now
      };
      entries.push(e);
      try { await save(); } catch (err) { entries.pop(); throw err; }
      return e;
    },

    update: async function (id, data) {
      requireUnlocked();
      var e = Vault.get(id);
      if (!e) throw new Error('not_found');
      var backup = Object.assign({}, e);
      e.service = data.service; e.login = data.login || '';
      e.password = data.password; e.note = data.note || ''; e.updated = Date.now();
      try { await save(); } catch (err) { Object.assign(e, backup); throw err; }
      return e;
    },

    remove: async function (id) {
      requireUnlocked();
      var before = entries.slice();
      entries = entries.filter(function (e) { return e.id !== id; });
      try { await save(); } catch (err) { entries = before; throw err; }
    },

    changePassword: async function (newPassword) {
      requireUnlocked();
      var oldKey = key, oldSalt = salt;
      salt = randomBytes(16);
      key = await deriveKey(newPassword, salt, iter);
      try { await save(); } catch (err) { key = oldKey; salt = oldSalt; throw err; }
    },

    exportBlob: function () {
      requireUnlocked();
      return localStorage.getItem(STORAGE_KEY) || '';
    },

    importBlob: async function (text, password) {
      var blob = parseBlob(text.trim());
      var k = await deriveKey(password, fromB64(blob.salt), blob.iter);
      var list = await decryptBlob(blob, k);   // бросит bad_password
      localStorage.setItem(STORAGE_KEY, JSON.stringify(blob));
      key = k; salt = fromB64(blob.salt); iter = blob.iter; entries = list;
    },

    // ---------- генератор паролей ----------
    generate: function (length, opts) {
      opts = opts || {};
      var sets = [];
      if (opts.lower !== false) sets.push('abcdefghijkmnpqrstuvwxyz');
      if (opts.upper !== false) sets.push('ABCDEFGHJKLMNPQRSTUVWXYZ');
      if (opts.digits !== false) sets.push('23456789');
      if (opts.symbols !== false) sets.push('!@#$%^&*-_=+?');
      if (!sets.length) sets.push('abcdefghijkmnpqrstuvwxyz', '23456789');

      var n = Math.max(8, Math.min(64, length | 0 || 20));
      n = Math.max(n, sets.length);
      var all = sets.join('');

      function randInt(max) {
        var lim = Math.floor(0x100000000 / max) * max, a = new Uint32Array(1);
        do { crypto.getRandomValues(a); } while (a[0] >= lim);
        return a[0] % max;
      }

      var out = sets.map(function (s) { return s[randInt(s.length)]; });
      while (out.length < n) out.push(all[randInt(all.length)]);
      for (var i = out.length - 1; i > 0; i--) {       // перемешивание Фишера–Йетса
        var j = randInt(i + 1), t = out[i]; out[i] = out[j]; out[j] = t;
      }
      return out.join('');
    }
  };

  root.Vault = Vault;
  if (typeof module !== 'undefined' && module.exports) module.exports = Vault;
})(typeof window !== 'undefined' ? window : globalThis);
