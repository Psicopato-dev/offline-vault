/* app.js — интерфейс. Все данные рисуются через textContent (без innerHTML). */
(function () {
  'use strict';

  var IDLE_MS = 2 * 60 * 1000;      // автоблокировка при бездействии
  var BG_LOCK_MS = 60 * 1000;       // автоблокировка после ухода в фон
  var MIN_PW = 10;

  var app = document.getElementById('app');
  var view = '';
  var goBack = null;                // что делает кнопка «назад»
  var query = '';
  var idleTimer = null;
  var hiddenAt = null;
  var modalClose = null;
  var toastTimer = null;

  // ---------- мини-помощники для DOM ----------
  function h(tag, props) {
    var el = document.createElement(tag);
    props = props || {};
    if (tag === 'button' && !('type' in props)) el.setAttribute('type', 'button');
    Object.keys(props).forEach(function (k) {
      var v = props[k];
      if (v === false || v == null) return;
      if (k === 'class') el.className = v;
      else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
      else if (k === 'value') el.value = v;
      else el.setAttribute(k, v === true ? '' : v);
    });
    Array.prototype.slice.call(arguments, 2).forEach(function add(kid) {
      if (kid == null || kid === false) return;
      if (Array.isArray(kid)) kid.forEach(add);
      else el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    });
    return el;
  }

  function setChildren(el, nodes) {
    el.textContent = '';
    nodes.forEach(function (n) { el.append(n); });
  }

  function show() {
    setChildren(app, Array.prototype.slice.call(arguments));
    window.scrollTo(0, 0);
  }

  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function iconBtn(label, aria, fn) {
    return h('button', { class: 'icon', 'aria-label': aria, onclick: fn }, label);
  }

  function header(title, opts) {
    opts = opts || {};
    return h('header', { class: 'bar' },
      opts.back ? iconBtn('←', 'Назад', opts.back) : null,
      h('h1', null, title),
      h('div', { class: 'spacer' }),
      opts.actions || null);
  }

  function pwInput(placeholder) {
    return h('input', { type: 'password', placeholder: placeholder, autocomplete: 'off',
                        autocapitalize: 'none', spellcheck: 'false' });
  }

  function field(label, input) {
    return h('label', { class: 'field' }, h('span', null, label), input);
  }

  async function withBusy(btn, label, fn) {
    var old = btn.textContent;
    btn.disabled = true; btn.textContent = label;
    try { return await fn(); }
    finally { btn.disabled = false; btn.textContent = old; }
  }

  function toast(msg) {
    var old = document.querySelector('.toast');
    if (old) old.remove();
    var t = h('div', { class: 'toast' }, msg);
    document.body.append(t);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.remove(); }, 2400);
  }

  function askConfirm(text, okLabel, danger) {
    return new Promise(function (resolve) {
      var overlay;
      function done(v) { overlay.remove(); modalClose = null; resolve(v); }
      overlay = h('div', { class: 'overlay' },
        h('div', { class: 'dialog' },
          h('p', null, text),
          h('div', { class: 'row' },
            h('button', { class: 'btn', onclick: function () { done(false); } }, 'Отмена'),
            h('button', { class: 'btn ' + (danger ? 'danger' : 'primary'),
                          onclick: function () { done(true); } }, okLabel || 'ОК'))));
      modalClose = function () { done(false); };
      document.body.append(overlay);
    });
  }

  function copy(text, what) {
    try {
      if (window.Android && window.Android.copy) {
        window.Android.copy(text);
        toast(what + ' скопирован · буфер очистится через 30 с');
      } else if (navigator.clipboard) {
        navigator.clipboard.writeText(text);
        toast(what + ' скопирован');
      } else {
        toast('Копирование недоступно');
      }
    } catch (e) { toast('Не удалось скопировать'); }
  }

  function errText(ex) {
    if (ex && ex.message === 'bad_password') return 'Неверный пароль';
    if (ex && ex.message === 'bad_format') return 'Это не похоже на резервную копию';
    return 'Ошибка: ' + (ex && ex.message ? ex.message : ex);
  }

  // ---------- блокировка ----------
  function resetIdle() {
    clearTimeout(idleTimer);
    if (window.Vault.isUnlocked()) idleTimer = setTimeout(lockNow, IDLE_MS);
  }
  ['pointerdown', 'keydown', 'input', 'scroll'].forEach(function (ev) {
    document.addEventListener(ev, resetIdle, { passive: true, capture: true });
  });

  function lockNow() {
    clearTimeout(idleTimer);
    window.Vault.lock();
    query = '';
    if (modalClose) modalClose();
    viewLock();
  }

  // вызывается из Kotlin: приложение ушло в фон / вернулось
  window.__bg = function () { hiddenAt = Date.now(); };
  window.__fg = function () {
    if (hiddenAt !== null && window.Vault.isUnlocked() && Date.now() - hiddenAt > BG_LOCK_MS) lockNow();
    hiddenAt = null;
  };
  // кнопка «назад» на телефоне: true — обработали, false — закрыть приложение
  window.__back = function () {
    if (modalClose) { modalClose(); return true; }
    if (goBack) { goBack(); return true; }
    return false;
  };

  // ---------- экраны ----------
  function viewSetup() {
    view = 'setup'; goBack = null;
    var p1 = pwInput('Мастер-пароль'), p2 = pwInput('Повтори пароль');
    var err = h('p', { class: 'error' });
    var btn = h('button', { class: 'btn primary', type: 'submit' }, 'Создать хранилище');
    var form = h('form', { class: 'card stack', onsubmit: async function (e) {
      e.preventDefault(); err.textContent = '';
      if (p1.value.length < MIN_PW) { err.textContent = 'Минимум ' + MIN_PW + ' символов'; return; }
      if (p1.value !== p2.value) { err.textContent = 'Пароли не совпадают'; return; }
      try {
        await withBusy(btn, 'Создаю…', function () { return window.Vault.create(p1.value); });
        p1.value = ''; p2.value = '';
        resetIdle(); viewList();
      } catch (ex) { err.textContent = errText(ex); }
    } }, p1, p2, err, btn);
    show(
      h('div', { class: 'hero' },
        h('div', { class: 'logo' }, '🔐'),
        h('h1', null, 'Офлайн-сейф'),
        h('p', { class: 'muted' }, 'Придумай мастер-пароль. Он нигде не хранится — если забудешь, данные не восстановить.')),
      form,
      h('button', { class: 'link', onclick: function () { viewImport('setup'); } }, 'Восстановить из резервной копии'));
  }

  function viewLock() {
    view = 'lock'; goBack = null;
    var pw = pwInput('Мастер-пароль');
    var err = h('p', { class: 'error' });
    var btn = h('button', { class: 'btn primary', type: 'submit' }, 'Разблокировать');
    var form = h('form', { class: 'card stack', onsubmit: async function (e) {
      e.preventDefault(); err.textContent = '';
      if (!pw.value) return;
      try {
        await withBusy(btn, 'Проверяю…', async function () {
          try { await window.Vault.unlock(pw.value); }
          catch (ex) { await sleep(1000); throw ex; }   // пауза против перебора
        });
        pw.value = '';
        resetIdle(); viewList();
      } catch (ex) { err.textContent = errText(ex); pw.select(); }
    } }, pw, err, btn);
    show(
      h('div', { class: 'hero' },
        h('div', { class: 'logo' }, '🔒'),
        h('h1', null, 'Хранилище заблокировано')),
      form,
      h('button', { class: 'link', onclick: function () { viewImport('lock'); } }, 'Восстановить из резервной копии'),
      h('button', { class: 'link danger', onclick: async function () {
        if (await askConfirm('Все записи на этом телефоне будут удалены безвозвратно. Продолжить?', 'Стереть', true)) {
          window.Vault.wipe(); toast('Хранилище стёрто'); viewSetup();
        }
      } }, 'Забыл пароль — стереть хранилище'));
    setTimeout(function () { pw.focus(); }, 80);
  }

  function viewList() {
    view = 'list'; goBack = null;
    var items = h('div', { class: 'items' });
    var search = h('input', { type: 'search', class: 'search', placeholder: 'Поиск…', autocomplete: 'off',
      value: query, oninput: function () { query = search.value; renderItems(); } });

    function renderItems() {
      var q = query.trim().toLowerCase();
      var all = window.Vault.list();
      var list = all.filter(function (e) {
        return !q || e.service.toLowerCase().indexOf(q) !== -1 || e.login.toLowerCase().indexOf(q) !== -1;
      }).sort(function (a, b) { return a.service.localeCompare(b.service, 'ru'); });
      setChildren(items, list.length ? list.map(function (e) {
        return h('button', { class: 'item', onclick: function () { viewDetail(e.id); } },
          h('b', null, e.service), e.login ? h('small', null, e.login) : null);
      }) : [h('p', { class: 'muted center' },
        all.length ? 'Ничего не найдено' : 'Пока пусто. Нажми «+», чтобы добавить первую запись.')]);
    }

    show(
      header('Пароли (' + window.Vault.list().length + ')', { actions: [
        iconBtn('⚙', 'Настройки', function () { viewSettings(); }),
        iconBtn('🔒', 'Заблокировать', function () { lockNow(); })
      ] }),
      search, items,
      h('button', { class: 'fab', 'aria-label': 'Добавить', onclick: function () { viewForm(null); } }, '+'));
    renderItems();
  }

  function row(label) {
    var content = Array.prototype.slice.call(arguments, 1);
    return h('div', { class: 'row-field' },
      h('small', { class: 'muted' }, label),
      h('div', { class: 'val' }, content));
  }

  function viewDetail(id) {
    var e = window.Vault.get(id);
    if (!e) { viewList(); return; }
    view = 'detail'; goBack = viewList;
    var shown = false, MASK = '••••••••••';
    var pwText = h('code', null, MASK);
    show(
      header(e.service, { back: function () { viewList(); } }),
      h('div', { class: 'card stack' },
        row('Логин', h('code', null, e.login || '—'),
          e.login ? iconBtn('📋', 'Копировать логин', function () { copy(e.login, 'Логин'); }) : null),
        row('Пароль', pwText,
          iconBtn('👁', 'Показать пароль', function () {
            shown = !shown; pwText.textContent = shown ? e.password : MASK;
          }),
          iconBtn('📋', 'Копировать пароль', function () { copy(e.password, 'Пароль'); })),
        e.note ? row('Заметка', h('span', { class: 'note' }, e.note)) : null),
      h('div', { class: 'card stack' },
        h('button', { class: 'btn', onclick: function () { viewForm(id); } }, 'Изменить'),
        h('button', { class: 'btn danger', onclick: async function () {
          if (await askConfirm('Удалить «' + e.service + '»?', 'Удалить', true)) {
            try { await window.Vault.remove(id); toast('Удалено'); viewList(); }
            catch (ex) { toast(errText(ex)); }
          }
        } }, 'Удалить')));
  }

  function viewForm(id) {
    var old = id ? window.Vault.get(id) : null;
    view = 'form';
    goBack = function () { if (old) viewDetail(id); else viewList(); };

    var service = h('input', { type: 'text', placeholder: 'Например, github.com', value: old ? old.service : '',
      autocomplete: 'off', autocapitalize: 'none', maxlength: 100 });
    var login = h('input', { type: 'text', placeholder: 'Логин или email', value: old ? old.login : '',
      autocomplete: 'off', autocapitalize: 'none', maxlength: 200 });
    var password = h('input', { type: 'password', placeholder: 'Пароль', value: old ? old.password : '',
      autocomplete: 'off', autocapitalize: 'none', spellcheck: 'false', maxlength: 500 });
    var note = h('textarea', { rows: 3, placeholder: 'Необязательно', value: old ? old.note : '', maxlength: 2000 });

    var eye = iconBtn('👁', 'Показать пароль', function () {
      password.type = password.type === 'password' ? 'text' : 'password';
    });
    var lenLabel = h('b', null, '20');
    var len = h('input', { type: 'range', min: 8, max: 40, value: 20,
      oninput: function () { lenLabel.textContent = len.value; } });
    var sym = h('input', { type: 'checkbox', checked: true });
    var gen = h('button', { class: 'btn', onclick: function () {
      password.value = window.Vault.generate(parseInt(len.value, 10), { symbols: sym.checked });
      password.type = 'text';
    } }, '🎲 Сгенерировать пароль');

    var err = h('p', { class: 'error' });
    var save = h('button', { class: 'btn primary', type: 'submit' }, 'Сохранить');

    var form = h('form', { class: 'stack', onsubmit: async function (ev) {
      ev.preventDefault(); err.textContent = '';
      var data = { service: service.value.trim(), login: login.value.trim(),
                   password: password.value, note: note.value.trim() };
      if (!data.service) { err.textContent = 'Укажи название сервиса'; return; }
      if (!data.password) { err.textContent = 'Укажи пароль'; return; }
      try {
        await withBusy(save, 'Сохраняю…', function () {
          return old ? window.Vault.update(id, data) : window.Vault.add(data);
        });
        toast('Сохранено');
        if (old) viewDetail(id); else viewList();
      } catch (ex) { err.textContent = errText(ex); }
    } },
      h('div', { class: 'card stack' },
        field('Сервис', service),
        field('Логин', login),
        h('div', { class: 'field' }, h('span', null, 'Пароль'), h('div', { class: 'inline' }, password, eye)),
        h('div', { class: 'gen' },
          h('div', { class: 'inline' }, h('span', { class: 'muted' }, 'Длина:'), lenLabel, len),
          h('label', { class: 'check' }, sym, h('span', null, 'Спецсимволы')),
          gen),
        field('Заметка', note)),
      err, save);

    show(header(old ? 'Изменить' : 'Новая запись', { back: function () { goBack(); } }), form);
  }

  function viewSettings() {
    view = 'settings'; goBack = viewList;
    show(
      header('Настройки', { back: function () { viewList(); } }),
      h('div', { class: 'card stack' },
        h('button', { class: 'btn', onclick: function () { viewChangePw(); } }, 'Сменить мастер-пароль'),
        h('button', { class: 'btn', onclick: function () { viewExport(); } }, 'Резервная копия (экспорт)'),
        h('button', { class: 'btn', onclick: function () { viewImport('settings'); } }, 'Восстановить из копии (импорт)'),
        h('button', { class: 'btn', onclick: function () { lockNow(); } }, 'Заблокировать')),
      h('div', { class: 'card stack' },
        h('p', { class: 'muted' }, 'Приложение полностью офлайн: у него нет разрешения на доступ к интернету. ' +
          'Данные лежат только на этом телефоне в зашифрованном виде (AES-256-GCM, ключ из мастер-пароля через PBKDF2).'),
        h('p', { class: 'muted' }, 'Автоблокировка: 2 минуты бездействия или 1 минута в фоне. ' +
          'Скриншоты в приложении запрещены.')));
  }

  function viewChangePw() {
    view = 'changepw'; goBack = viewSettings;
    var cur = pwInput('Текущий пароль'), n1 = pwInput('Новый пароль'), n2 = pwInput('Повтори новый пароль');
    var err = h('p', { class: 'error' });
    var btn = h('button', { class: 'btn primary', type: 'submit' }, 'Сменить пароль');
    var form = h('form', { class: 'card stack', onsubmit: async function (e) {
      e.preventDefault(); err.textContent = '';
      if (n1.value.length < MIN_PW) { err.textContent = 'Новый пароль: минимум ' + MIN_PW + ' символов'; return; }
      if (n1.value !== n2.value) { err.textContent = 'Новые пароли не совпадают'; return; }
      try {
        var ok = await withBusy(btn, 'Проверяю…', function () { return window.Vault.verify(cur.value); });
        if (!ok) { err.textContent = 'Текущий пароль неверный'; return; }
        await withBusy(btn, 'Меняю…', function () { return window.Vault.changePassword(n1.value); });
        toast('Мастер-пароль изменён'); viewSettings();
      } catch (ex) { err.textContent = errText(ex); }
    } }, cur, n1, n2, err, btn,
      h('p', { class: 'muted' }, 'Старые резервные копии останутся с прежним паролем.'));
    show(header('Смена пароля', { back: function () { viewSettings(); } }), form);
  }

  function viewExport() {
    view = 'export'; goBack = viewSettings;
    var blob = window.Vault.exportBlob();
    var ta = h('textarea', { rows: 6, readonly: true, value: blob });
    show(
      header('Резервная копия', { back: function () { viewSettings(); } }),
      h('div', { class: 'card stack' },
        h('p', { class: 'muted' }, 'Копия зашифрована твоим мастер-паролем. Отправь её себе (Избранное в Telegram, почта, облако) ' +
          'и храни надёжно. Для восстановления понадобится этот же мастер-пароль.'),
        h('button', { class: 'btn primary', onclick: function () {
          if (window.Android && window.Android.share) window.Android.share(blob);
          else toast('Доступно только в приложении');
        } }, 'Поделиться копией'),
        ta,
        h('p', { class: 'muted' }, 'Размер: ' + blob.length + ' символов')));
  }

  function viewImport(origin) {
    view = 'import';
    var back = { setup: viewSetup, lock: viewLock, settings: viewSettings }[origin];
    goBack = back;
    var ta = h('textarea', { rows: 6, placeholder: 'Вставь сюда текст резервной копии',
      autocomplete: 'off', spellcheck: 'false' });
    var pw = pwInput('Мастер-пароль из копии');
    var err = h('p', { class: 'error' });
    var btn = h('button', { class: 'btn primary', type: 'submit' }, 'Восстановить');
    var form = h('form', { class: 'card stack', onsubmit: async function (e) {
      e.preventDefault(); err.textContent = '';
      if (!ta.value.trim()) { err.textContent = 'Вставь текст резервной копии'; return; }
      if (!pw.value) { err.textContent = 'Введи мастер-пароль'; return; }
      if (origin !== 'setup' &&
          !(await askConfirm('Текущее хранилище будет заменено копией. Продолжить?', 'Заменить', true))) return;
      try {
        await withBusy(btn, 'Расшифровываю…', function () { return window.Vault.importBlob(ta.value, pw.value); });
        toast('Восстановлено'); resetIdle(); viewList();
      } catch (ex) {
        err.textContent = ex && ex.message === 'bad_password' ? 'Неверный пароль или копия повреждена' : errText(ex);
      }
    } }, ta, pw, err, btn);
    show(header('Восстановление', { back: function () { back(); } }), form);
  }

  // ---------- старт ----------
  if (!window.crypto || !window.crypto.subtle) {
    show(h('div', { class: 'card' },
      h('p', { class: 'error' }, 'Веб-криптография недоступна. Обнови «Android System WebView» в Google Play.')));
  } else if (window.Vault.exists()) {
    viewLock();
  } else {
    viewSetup();
  }
})();
