package app.offlinevault

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader

/**
 * Вся логика и интерфейс — в assets (index.html, app.js, vault.js).
 * Здесь только WebView и три мостика к системе: буфер обмена, «поделиться», кнопка «назад».
 * В манифесте нет разрешения INTERNET, поэтому сеть недоступна физически.
 */
class MainActivity : Activity() {

    private lateinit var web: WebView
    private val handler = Handler(Looper.getMainLooper())
    private val clearClipRunnable = Runnable { clearClipboard() }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Запрет скриншотов, записи экрана и превью в списке недавних приложений
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )

        // Отдаём файлы из assets по «https://appassets.androidplatform.net/…».
        // Это безопасный контекст, поэтому работает Web Crypto.
        val assetLoader = WebViewAssetLoader.Builder()
            .setDomain(HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0F1216"))
        web.importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true          // localStorage — здесь лежит зашифрованное хранилище
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.setSupportZoom(false)

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

            // Любые переходы на чужие адреса блокируем
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean = request.url.host != HOST
        }

        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("https://$HOST/assets/index.html")
    }

    override fun onStart() {
        super.onStart()
        web.evaluateJavascript("window.__fg && window.__fg()", null)
    }

    override fun onStop() {
        super.onStop()
        web.evaluateJavascript("window.__bg && window.__bg()", null)
    }

    // Кнопка «назад»: сначала даём странице вернуться на предыдущий экран
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.__back && window.__back()) === true") { result ->
            if (result != "true") finish()
        }
    }

    private fun clearClipboard() {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            if (Build.VERSION.SDK_INT >= 28) {
                cm.clearPrimaryClip()
            } else {
                cm.setPrimaryClip(ClipData.newPlainText("", ""))
            }
        } catch (e: Exception) {
            // Android может запретить доступ к буферу из фона — это не критично
        }
    }

    /** Методы, которые страница может вызвать как window.Android.xxx(...) */
    inner class Bridge {

        @JavascriptInterface
        fun copy(text: String) {
            runOnUiThread {
                try {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clip = ClipData.newPlainText("secret", text)
                    if (Build.VERSION.SDK_INT >= 33) {
                        // Android 13+: не показывать содержимое в превью буфера
                        val extras = PersistableBundle()
                        extras.putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true)
                        clip.description.extras = extras
                    }
                    cm.setPrimaryClip(clip)
                    handler.removeCallbacks(clearClipRunnable)
                    handler.postDelayed(clearClipRunnable, CLIP_CLEAR_MS)
                } catch (e: Exception) {
                    // ничего: страница покажет своё сообщение
                }
            }
        }

        @JavascriptInterface
        fun share(text: String) {
            runOnUiThread {
                val send = Intent(Intent.ACTION_SEND)
                send.type = "text/plain"
                send.putExtra(Intent.EXTRA_TEXT, text)
                startActivity(Intent.createChooser(send, "Резервная копия"))
            }
        }
    }

    companion object {
        private const val HOST = "appassets.androidplatform.net"
        private const val CLIP_CLEAR_MS = 30_000L
    }
}
